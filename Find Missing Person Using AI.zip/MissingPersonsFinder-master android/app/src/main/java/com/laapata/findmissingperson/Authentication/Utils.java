package com.laapata.findmissingperson.Authentication;

public class Utils {

    //Email Validation pattern
    public static final String regEx = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";

    //Fragments Tags
    public static final String LoginFragment = "LoginFragment";
    public static final String RegisterFragment = "RegisterFragment";
    public static final String RegisterPoliceFragment = "";
    public static final String PassRecFragment = "PassRecFragment";

    public static final String Fragment1 = "Fragment1";
    public static final String Fragment2 = "Fragment2";
    public static final String Fragment3 = "Fragment3";
    public static final String Fragment4 = "Fragment4";
    public static final String Fragment5 = "Fragment5";





}