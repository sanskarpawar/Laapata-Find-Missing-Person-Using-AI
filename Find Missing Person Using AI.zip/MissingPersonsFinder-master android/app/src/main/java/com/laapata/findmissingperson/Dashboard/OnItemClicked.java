package com.laapata.findmissingperson.Dashboard;

import com.laapata.findmissingperson.ModelClasses.FoundPersonModel;
import com.laapata.findmissingperson.ModelClasses.GigsData;

public interface OnItemClicked {
    void onItemClicked(FoundPersonModel gigsData);
}
