package com.laapata.findmissingperson.Notification;

public class MyResponse {

    public int success;
}
